<?php $__env->startSection('content'); ?>
    <div class="content-body">
        <div class="container-fluid">
            <div class="form-head mb-4 d-flex flex-wrap align-items-center">
                <div class="me-auto">
                    <h2 class="font-w600 mb-0">Dashboard</h2>
                    <p class="text-light">Analisis Perbandingan Metode Simple Additive Weighting (SAW) dan VIKOR pada
                        Penetapan Wisudawan Terbaik </p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Metode SAW</h4>
                        </div>
                        <div class="card-body p-3">
                            <a href="<?php echo e(route('getAlternatif')); ?>" class="btn btn-primary btn-block mt-3">Tabel Data Mahasiswa</a>
                            <a href="<?php echo e(route('getMetodeSawTabelNormalisasi')); ?>" class="btn btn-primary btn-block mt-3">Tabel Normalisasi</a>
                            <a href="<?php echo e(route('getMetodeSawTabelPerangkingan')); ?>" class="btn btn-primary btn-block mt-3">Tabel Perangkingan</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PROJECT\DILLANEW\resources\views/admin/metode-saw.blade.php ENDPATH**/ ?>